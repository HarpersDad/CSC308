//
//  ViewController.swift
//  Assignment5
//
//  Created by Clifton Lindsey on 3/9/21.
//

import UIKit

class ViewController: UIViewController
{
    // dictionary with winnable values
    var numbers = ["100": 100,
                    "200": 200,
                    "300": 300,
                    "400": 400,
                    "500": 500,
                    "600": 600];
    
    // cumulative total of won values
    var total = 0;
    
    // variable to count how many buttons are pressed per game
    var choiceCount = 0;
    
    // variable that is used to determine if the game has ended
    var gameEnded = false;
    
    // these variables store each button
    var tlb = UIButton();
    var trb = UIButton();
    var mlb = UIButton();
    var mrb = UIButton();
    var blb = UIButton();
    var brb = UIButton();
    
    // funciton that returns a won amount at random
    func randomNumber() -> String
    {
        // variable that is given a value at random from remaining dictionary entries
        let randNum = numbers.randomElement()!.0;
        
        // removes instanced value from dictionary
        numbers.removeValue(forKey: randNum)
        
        // adds instanced value to total
        total += Int(randNum)!;
        
        // returns instanced value
        return (randNum);
    }
    
    // function to create a pop-up alert once conditions are met that ends the game
    func gameOver()
    {
        // checks if the choice count has reached two
        if choiceCount == 2
        {
            // sets the gameEnded boolean to true
            gameEnded = true;
            
            // title for pop-up window
            let alertController = UIAlertController(title: "Congratulations", message: ("You got " + String(total) + " dollars!"), preferredStyle: UIAlertController.Style.alert)
            
            // this button quits the application
            let exitAction = UIAlertAction(title: "Exit", style: UIAlertAction.Style.default)
            {
                _ in
                    // exits the game
                    exit(0)
            }
                
            // this button restarts the game
            let resetAction = UIAlertAction(title: "Play Again", style: UIAlertAction.Style.default)
            {
                [self]_ in
                
                    // function call to reset the game
                    gameReset();
                
                    // resets the choiceCount to zero
                    choiceCount = 0;
                
                    // resets the total amount to zero
                    total = 0;
                    
                    // resets the dictionary with the winnable amounts
                    numbers = ["100": 100,
                               "200": 200,
                               "300": 300,
                               "400": 400,
                               "500": 500,
                               "600": 600];
                    
                    // sets the gameEnded boolean back to false
                    gameEnded = false
            }
            
            alertController.addAction(resetAction);
            alertController.addAction(exitAction);
            
            present(alertController, animated: true, completion: nil);
        }
    }
    
    // function that resets the game to its original state
    func gameReset()
    {
        // each block returns the dollar sign icon for its respective position, removes the won amount text, and re-enables each button
        
        // top right button
        trb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        trb.setTitle("", for: UIControl.State.normal);
        trb.imageRect(forContentRect: CGRect(x: 260, y: 113, width: 120, height: 120));
        trb.draw(CGRect(x: 260, y: 113, width: 10, height: 10));
        trb.isEnabled = true;
        
        // top left button
        tlb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        tlb.setTitle("", for: UIControl.State.normal);
        tlb.imageRect(forContentRect: CGRect(x: 40, y: 113, width: 120, height: 120));
        tlb.draw(CGRect(x: 40, y: 113, width: 10, height: 10));
        tlb.isEnabled = true;
        
        // middle right button
        mrb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        mrb.setTitle("", for: UIControl.State.normal);
        mrb.imageRect(forContentRect: CGRect(x: 260, y: 304, width: 120, height: 120));
        mrb.draw(CGRect(x: 260, y: 304, width: 10, height: 10));
        mrb.isEnabled = true;
        
        // middle left button
        mlb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        mlb.setTitle("", for: UIControl.State.normal);
        mlb.imageRect(forContentRect: CGRect(x: 40, y: 304, width: 120, height: 120));
        mlb.draw(CGRect(x: 40, y: 304, width: 10, height: 10));
        mlb.isEnabled = true;
        
        // bottom right button
        brb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        brb.setTitle("", for: UIControl.State.normal);
        brb.imageRect(forContentRect: CGRect(x: 260, y: 502, width: 120, height: 120));
        brb.draw(CGRect(x: 260, y: 502, width: 10, height: 10));
        brb.isEnabled = true;
        
        // bottom left button
        blb.setImage(UIImage(named: "d2.jpg"), for: UIControl.State.normal);
        blb.setTitle("", for: UIControl.State.normal);
        blb.imageRect(forContentRect: CGRect(x: 40, y: 502, width: 120, height: 120));
        blb.draw(CGRect(x: 40, y: 502, width: 10, height: 10));
        blb.isEnabled = true;
        
        // resets text at bottom of screen to original state
        totalDollars.text = "You've got 0 dollars!";
    }
    
    // funtion call that replaces dollar sign image with random monetary amount won
    func whenClicked(sender: UIButton)
    {
        // block that removes image, sets dollar mount won, and disables button
        sender.setImage(nil, for: UIControl.State.normal);
        sender.setTitle(randomNumber(), for: UIControl.State.normal);
        sender.setTitleColor(UIColor.blue, for: UIControl.State.normal);
        sender.isEnabled = false;
        
        // increases chouceCount variable
        choiceCount += 1;
        
        // shows user how much money they have won
        totalDollars.text = "You've got <money> dollars!";
        
        // replaces <money> with the value held in the total variable
        totalDollars.text = totalDollars.text?.replacingOccurrences(of: "<money>", with: String(total));
        
        // function call to see if the game has ended
        gameOver();
    }
    
    // UI button
    @IBAction func bottomRightButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        brb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
    
    // UI button
    @IBAction func bottomLeftButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        blb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
    
    // UI button
    @IBAction func midRightButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        mrb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
    
    // UI button
    @IBAction func midLeftButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        mlb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
    
    // UI button
    @IBAction func topRightButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        trb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
    
    // UI button
    @IBAction func topLeftButton(_ sender: UIButton)
    {
        // stores sender as a variable to allow for use later
        trb = sender;
        
        // function call that changes image to won amount
        whenClicked(sender: sender);
    }
        
    // UI button
    @IBAction func helpButton(_ sender: UIButton)
    {
        // pop-up that shows you how to play the game
        let alertController = UIAlertController(title: "How To Play", message: "Click two buttons to find your reward.", preferredStyle: UIAlertController.Style.alert);
        
        // pop-up dismissal button
        let defaultAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.cancel, handler: nil);
        
        alertController.addAction(defaultAction);
        
        present(alertController, animated: true, completion: nil);
    }
    
    // text that shows current money won
    @IBOutlet weak var totalDollars: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

