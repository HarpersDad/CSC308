//
//  ThirdViewController.swift
//  Final
//
//  Created by Clifton Lindsey on 5/3/21.
//

import UIKit

// it is empty in here
class ThirdViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
