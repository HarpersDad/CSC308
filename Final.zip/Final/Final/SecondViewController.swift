//
//  SecondViewController.swift
//  Final
//
//  Created by Clifton Lindsey on 5/3/21.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource
{
    // function that returns number of sections based on foodCategory array size
    func numberOfSections(in tableView: UITableView) -> Int
    {
        return foodCategory.count;
    }
    
    // sets each categories size
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if (foodCategory[section] == "Dairy")
        {
            return 3;
        }
        else
        {
            return 2;
        }
    }
    
    // sets title for each row based on its position in the foodItems array
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        // sets up cell variable
        let cell = tableView.dequeueReusableCell(withIdentifier: "foodCell");
        
        // sets each cells text with the appropriate title
        cell!.textLabel!.text = foodItems[indexPath.section][indexPath.row];
        
        // returns the cell
        return cell!;
    }
    
    // sets title for each category of food in the array
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return foodCategory[section];
    }
    
    // funtion that returns the name of selected food, and the calories that are associated with that selection
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        // sets category of food chosen
        category = indexPath.section;
        
        // sets food chosen
        food = indexPath.row;
        
        //print("Category: " + foodCategory[category]);
        //print("Food: " + foodItems[category][food]);
        
        // function call to the popup that tells you how many calories are in the food chosen at selected weight
        popUp(varA: (foodItems[category][food]), varB: foodCalories[category][food]);
        
    }
    
    // popup function
    func popUp(varA: String, varB: Int)
    {
        // string variable
        var outText = " ounces of ";
        
        //print("totalOunces: ", UserDefaults.standard.integer(forKey: "totalOunces"))
        
        // if statement that changes string depending on condition
        if (String(UserDefaults.standard.integer(forKey: "totalOunces")) == "1")
        {
            outText = " ounce of "
        }
        
        // text for popup
        let alertController = UIAlertController(title: varA, message: ("Calories in " + String(UserDefaults.standard.integer(forKey: "totalOunces")) + outText + varA + ": " + String(UserDefaults.standard.integer(forKey: "totalOunces") * varB)), preferredStyle: UIAlertController.Style.alert)
        
        // popup dismissal button
        let popupButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default)
        {
            [self]_ in
        }
        
        // creates ok button for the popup
        alertController.addAction(popupButton);
        
        present(alertController, animated: true, completion: nil);
    }
    
    // variables
    @IBOutlet weak var foodTable: UITableView!;
    
    var category = 0;
    
    var food = 0;
    
    // arrays
    let foodCategory =
        [
            "Dairy",
            "Grains",
            "Fruit"
        ]
    
    let foodItems =
        [
            ["Milk", "Yogurt", "Cheese"],
            ["Rice", "Oats"],
            ["Apple", "Banana"]
            
        ]
    
    let foodCalories =
        [
            [12, 17, 114],
            [37, 110],
            [15, 25]
        ]

    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
