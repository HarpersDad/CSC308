//
//  ViewController.swift
//  Final
//
//  Created by Clifton Lindsey on 5/3/21.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    // sets number of components in picker view
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 2
    }
    
    // sets number of rows in each component depending on the component and array used
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if (component == 0)
        {
            return numbersA.count;
        }
        else if (component == 1)
        {
            return numbersB.count;
        }
        return 1;
    }
    
    // sets up component row contents depending on which component is chosen
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        // data used dependent on which picker is used
        if  (component == 0)
        {
            // sets numA variable
            numA.self = numbersA[row];
            
            // calls outputValue function
            outputValue(varA: numA, varB: numB);
            
            // returns row contents
            return String(numbersA[row]);
        }
        else if (component == 1)
        {
            // sets numB variable
            numB.self = numbersB[row];
           
            // calls outputValue function
            outputValue(varA: numA, varB: numB);
            
            // returns row contents
            return String(numbersB[row]);
        }
        else
        {
            // should never trigger
            return "empty";
        }
    }
    
    // array for component 0
    var numbersA =
        [
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9
        ]
    
    // array for component 1
    var numbersB =
        [
            0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
        ]
    
    // variables
    var numA: Int = 0;
    
    var numB: Int = 0;
    
    @IBOutlet weak var poundLabel: UILabel!
    
    @IBOutlet weak var ounceLabel: UILabel!
    
    @IBOutlet weak var outputLabel: UILabel!
    
    @IBOutlet weak var weightPicker: UIPickerView!
    
    // outputValue function used to set text and set variable for global use
    func outputValue(varA: Int, varB: Int)
    {
        
        //print("numA: ", varA, " numB: ", varB)
        
        UserDefaults.standard.setValue(((varA * 16) + varB), forKey: "totalOunces");
        
        //print("totalOunces", UserDefaults.standard.integer(forKey: "totalOunces"))
        
        outputLabel.text = String((varA * 16) + varB) + " Ounces";
        
        //print("varA: ", varA, " varB ", varB)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // sets up picker
        weightPicker.dataSource = self;
        weightPicker.delegate = self;
    }
}

