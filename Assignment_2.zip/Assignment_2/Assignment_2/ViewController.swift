//  CSC 308
//  Assignment_2
//
//  Created by Clifton Lindsey on 2/4/21.
//

import UIKit

class ViewController: UIViewController
{
    
    // contains variables for label
    var currentCity = "Lexington"
    var currentAttraction = "Keeneland"
    
    // controls label and image
    @IBOutlet weak var attractionPlace: UILabel!
    @IBOutlet weak var attractionImage: UIImageView!
    
    // function for which city is chosen
    @IBAction func cityChoice(_ sender: UISegmentedControl)
    {
        currentCity = sender.titleForSegment(at: sender.selectedSegmentIndex)!

        // sets the label for the current chosen city and attraction
        attractionPlace.text = currentCity + ": " + currentAttraction
    }
    
    // function for what attraction is chosen
    @IBAction func attractionChoice(_ sender: UISegmentedControl)
    {
        currentAttraction = sender.titleForSegment(at: sender.selectedSegmentIndex)!
        
        // switch statement that sets attractions according to city
        switch currentCity
        {
            case "Lexington":
                sender.removeAllSegments()
                sender.insertSegment(withTitle: "Keeneland", at: 0, animated: false)
                sender.insertSegment(withTitle: "Arboretum", at: 1, animated: false)
                
            case "Chicago":
                sender.removeAllSegments()
                sender.insertSegment(withTitle: "Cruise", at: 0, animated: false)
                sender.insertSegment(withTitle: "Millenium Park", at: 1, animated: false)
                sender.insertSegment(withTitle: "Planetarium", at: 2, animated: false)
                sender.insertSegment(withTitle: "Skydeck", at: 3, animated: false)
                
            case "Chengdu":
                sender.removeAllSegments()
                sender.insertSegment(withTitle: "Panda", at: 0, animated: false)
                sender.insertSegment(withTitle: "Pedestrian", at: 1, animated: false)
                
            case "Hong Kong":
                sender.removeAllSegments()
                sender.insertSegment(withTitle: "Disneyland", at: 0, animated: false)
                sender.insertSegment(withTitle: "Ocean Park", at: 1, animated: false)
                sender.insertSegment(withTitle: "The Peak", at: 2, animated: false)
                
            default:
                break
        }
        
        // sets the label for the current chosen city and attraction
        attractionPlace.text = currentCity + ": " + currentAttraction
        
        // sets the picture to the current chosen attraction
        attractionImage.image = UIImage(named: "\(currentAttraction).jpg")
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

