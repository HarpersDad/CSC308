//
//  ViewController.swift
//  Assignment3
//
//  Created by Clifton Lindsey on 2/25/21.
//

import UIKit

class ViewController: UIViewController
{
    //variables
    var weightUnits = "0";
    var waistUnits = "0";
    var selectedSex = "0";
    var waist = 0.0;
    var weight = 0.0;
    var bfp = 0.0;
    
    //text inputs with associated variables
    @IBOutlet weak var userName: UITextField!
    
    @IBOutlet weak var userWeight: UITextField!
    
    @IBOutlet weak var userWaist: UITextField!
    
    //text output
    @IBOutlet weak var resultsText: UITextView!
    
    //segmented controls
    @IBAction func maleFemaleSelector(_ sender: UISegmentedControl)
    {
        selectedSex = sender.titleForSegment(at: sender.selectedSegmentIndex)!;
    }
    
    @IBAction func poundsKiloSelector(_ sender: UISegmentedControl)
    {
        weightUnits = sender.titleForSegment(at: sender.selectedSegmentIndex)!;
    }
    
    @IBAction func inchesCentimeterSelector(_ sender: UISegmentedControl)
    {
        waistUnits = sender.titleForSegment(at: sender.selectedSegmentIndex)!;
    }
    
    //converts units
    func unitConversion()
    {
        weight = Double(userWeight.text!)!;
        waist = Double(userWaist.text!)!;
        
        if (weightUnits == "1")
        {
            weight = (weight * 0.453592);
        }
        
        if (waistUnits == "1")
        {
            waist = (waist * 2.54);
        }
    }
    
    func bodyFatCalc()
    {
        let a = (4.15 * waist);
        let b = (0.082 * weight);
        
        if (selectedSex == "0")
        {
            bfp = (a - b - 98.42) / weight;
        }
        else
        {
            bfp = (a - b - 76.76) / weight;
        }
        
        bfp = round(100 * bfp);
    }
    
    //results text
    @IBAction func resultsButton(_ sender: UIButton)
    {
        unitConversion();
        bodyFatCalc();
        
        resultsText.text = "Hi, <username>, thank you for using this body fat calculator.  Your body fat percentage is estimated to be <bfp>% according to the YMCA method.";
        
        resultsText.text = resultsText.text.replacingOccurrences(of: "<username>", with: userName.text!);
        resultsText.text = resultsText.text.replacingOccurrences(of: "<bfp>", with: String(bfp));
        print(bfp);
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

