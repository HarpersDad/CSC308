//
//  ViewController.swift
//  Assignment_7
//
//  Created by Clifton Lindsey on 4/12/21.
//

import UIKit
import WebKit

// protocols for the following functions
//###################################################################################################

// to change text color
protocol newTextColor
{
    func newColor(a: Int, b: Int, c: Int)
}

// to change websitte url
protocol newWebSite
{
    func changeSite(a: String)
}

// main class
class ViewController: UIViewController, newTextColor, newWebSite
{
    // variable that holds the desired url
    var url = URL(string: "");
    
    // UI variables
    //###################################################################################################
    
    // the variable names should be self explaining
    @IBOutlet weak var pictureTitle: UILabel!
    
    @IBOutlet weak var wikiImage: UIImageView!
    
    @IBOutlet weak var wikiArticle: WKWebView!
    
    @IBAction func topicSelector(_ sender: UIButton)
    {
        performSegue(withIdentifier: "wikiSelector", sender: sender)
    }
    
    @IBAction func textColor(_ sender: UIButton)
    {
        performSegue(withIdentifier: "colorSelector", sender: sender)
    }
    
    // functions
    //###################################################################################################
    
    // function that changes the title text color
    func newColor(a: Int, b: Int, c:Int)
    {
        //print(a, " ", b, " ", c)
        
        pictureTitle.textColor = UIColor(red: CGFloat(a), green: CGFloat(b), blue: CGFloat(c), alpha: 1.0)
    }
    
    // function to change url and load site dependent on what animal/plant is chosen
    func changeSite(a: String)
    {
        url = URL(string: "https://en.wikipedia.org/wiki/" + a)
        wikiArticle.load(URLRequest(url: url!));
        //print("Initial Scene: " + a)
        pictureTitle.text = a;
    }
    
    // override to load view
    //###################################################################################################
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional letup after loading the view.
        
        pictureTitle.text = "Dandelion";
        
        wikiImage.image = UIImage(named: "Dandelion.jpg");
        
        url = URL(string: "https://en.wikipedia.org/wiki/Dandelion");
        wikiArticle.load(URLRequest(url: url!));
        
        // no matter what I tried to do, I was unable to get the webView to become transparent so that the
        // background image could show through.
    }
    
    // override function for protocols
    //###################################################################################################
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if let destination = segue.destination as? thirdViewController
        {
            destination.delegate = self;
            // Other initializations as needed
        }
        
        if let destination = segue.destination as? secondViewController
        {
            destination.delegate = self;
        }
    }
}

