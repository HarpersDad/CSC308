//
//  secondViewController.swift
//  Assignment_7
//
//  Created by Clifton Lindsey on 4/16/21.
//

import UIKit

// main class
//###################################################################################################
class secondViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource
{
    // variable for protocol
    var delegate: newWebSite?;

    // functions
    //###################################################################################################
    
    // $
    // function set for pickers
    
    // number of partitions in picker
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    // sets rows for each picker
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        // switch statement that changes row number dependent on the length of used array
        switch pickerView.tag
        {
        case 0:
            return typeData.count;
        case 1:
            return nameData.count;
        default:
            return 1;
        }
    }
    
    // function used to insert data into picker
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        // data used dependent on which picker is used
        switch pickerView.tag
        {
        case 0:
            return typeData[row];
        case 1:
            return nameData[row];
        default:
            return "empty";
        }
    }
    
    // variable to hold last used row value
    var priorRow = 0;
    
    // funtion used to record data selected in picker, also used to set image, url, and title
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        // if first picker
        if (pickerView.tag == 0)
        {
            // switch statement that tracks row position, uses correct data to fill picker, and sets image
            switch (row)
            {
                case 0:
                    if (priorRow > 2)
                    {
                        priorRow = 2;
                    }
                    nameData = ["Dandelion", "Beargrass", "Hibiscus"];
                    chosenImage.image = UIImage(named: nameData[priorRow] + ".jpg");
                    priorRow = 0;
                    
                    // calls protocol funtion
                    delegate?.changeSite(a: nameData[row])
                    
                case 1:
                    if (priorRow > 2)
                    {
                        priorRow = 2;
                    }
                    nameData = ["Panda", "Elephant", "Lion", "Penguin", "Wolf", "Bear"];
                    chosenImage.image = UIImage(named: nameData[priorRow] + ".jpg");
                    priorRow = 0;
                    
                    // calls protocol function
                    delegate?.changeSite(a: nameData[row])
                    
                default:
                    print("nothing");
            }
        }
        
        // if second picker
        if (pickerView.tag == 1)
        {
            // tracks and sets picker location depending on selection
            pickerView.selectRow(row, inComponent: 0, animated: true);
            
            // sets image
            chosenImage.image = UIImage(named: nameData[row] + ".jpg");
            
            // calls protocol function
            delegate?.changeSite(a: nameData[row])
            
            // sets variable
            priorRow = row;
        }
        
        // not exactly sure but i think this updates the data used on the page
        nameSelector.reloadAllComponents();
        typeSelector.reloadAllComponents();
        chosenImage.reloadInputViews();
        
        // calls protocol function
        delegate?.changeSite(a: nameData[row])
    }
    // $
    
    // ui variables
    //###################################################################################################
    @IBOutlet weak var typeSelector: UIPickerView!
    
    // sets empty array
    var typeData:[String] = [String]();
    
    @IBOutlet weak var nameSelector: UIPickerView!
    
    // sets empty array
    var nameData:[String] = [String]();
    
    @IBOutlet weak var chosenImage: UIImageView!
    
    @IBAction func doneButton(_ sender: UIButton)
    {
        // dismisses window
        dismiss(animated: true, completion: nil)
    }
    
    // override
    //###################################################################################################
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // sets array with default data
        typeData = ["Plant", "Animal"];
        nameData = ["Dandelion", "Beargrass", "Hibiscus"]
        
        // sets default image
        chosenImage.image = UIImage(named: nameData[0] + ".jpg");
        
        // sets up picker
        typeSelector.dataSource = self;
        typeSelector.delegate = self;
        typeSelector.tag = 0;
        
        // sets up picker
        nameSelector.dataSource = self;
        nameSelector.delegate = self;
        nameSelector.tag = 1;
        
        // reloads view
        nameSelector.reloadAllComponents();
        typeSelector.reloadAllComponents();
        chosenImage.reloadInputViews();
    }
}
