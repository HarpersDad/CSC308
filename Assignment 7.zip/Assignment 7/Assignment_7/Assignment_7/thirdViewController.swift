//
//  thirdViewController.swift
//  Assignment_7
//
//  Created by Clifton Lindsey on 4/16/21.
//

import UIKit

// main class
//###################################################################################################
class thirdViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate
{
    
    // variables for hex array, and conversion into decimal
    var hexList = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"];
    var hPart1 = "";
    var hPart2 = "";
    var hPart3 = "";
    
    // decimal values from obtained from hex conversion
    var decimalA = 0;
    var decimalB = 0;
    var decimalC = 0;
    
    // protocol variable
    var delegate: newTextColor?
    
    // ui variables
    //###################################################################################################
    @IBOutlet weak var colorPicker: UIPickerView!
    
    @IBOutlet weak var greenLabel: UILabel!
    var g = 0;
    
    @IBOutlet weak var redLabel: UILabel!
    var r = 0;
    
    @IBOutlet weak var blueLabel: UILabel!
    var b = 0;
    
    @IBOutlet weak var textColorLabel: UILabel!
    
    //functions
    //###################################################################################################
    
    // roughly the same as the ones in the secondViewController
    // sets up totlal picker components
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 6
    }
    
    // each component size
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    
    {
        return hexList.count
    }
    
    // fills components with array values
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return hexList[row];
    }
    
    // sets hex strings to variables and then converts them to decimal through function call
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        
        // the picker components probably start at 0, but I started their count at 1 in my head
        
        // hex sttring comprised of picker components 1 and 2
        hPart1 = hexList[pickerView.selectedRow(inComponent: 0)] + hexList[pickerView.selectedRow(inComponent: 1)]
        
        // hex string comprised of picker components 3 and 4
        hPart2 = hexList[pickerView.selectedRow(inComponent: 2)] + hexList[pickerView.selectedRow(inComponent: 3)]
        
        // hex string comprised of picker components 5 and 6
        hPart3 = hexList[pickerView.selectedRow(inComponent: 4)] + hexList[pickerView.selectedRow(inComponent: 5)]
        
        //print(hString)
        
        // calls function to convert hex parts into a decimal
        convertToDecimal(a: hPart1, b: hPart2, c: hPart3)
    }
    
    // button that says you have had enough of this page
    @IBAction func doneButton(_ sender: UIButton)
    {
        delegate?.newColor(a: decimalA, b: decimalB, c: decimalC)
        
        dismiss(animated: true, completion: nil)
        
        //print(decimalA, " ", decimalB, " ", decimalC)
    }
    
    // function used to convert hex values into decimal, to be further used to create a color value
    func convertToDecimal(a: String, b: String, c: String)
    {
        // deciaml variables
        decimalA = (Int)(strtoul(a, nil, 16));
        decimalB = (Int)(strtoul(b, nil, 16));
        decimalC = (Int)(strtoul(c, nil, 16));
        
        // color values for each of the RGB values reflected onscreen by decimal value.
        greenLabel.text = (String)(decimalB);
        //greenLabel.textColor = UIColor(red: (CGFloat)(0)/255.0, green: (CGFloat)(decimalB)/255.0, blue: (CGFloat)(0)/255.0, alpha: 1.0)
        
        redLabel.text = (String)(decimalA);
        //redLabel.textColor = UIColor(red: (CGFloat)(decimalA)/255.0, green: (CGFloat)(0)/255.0, blue: (CGFloat)(0)/255.0, alpha: 1.0)
        
        blueLabel.text = (String)(decimalC);
        //blueLabel.textColor = UIColor(red: (CGFloat)(0)/255.0, green: (CGFloat)(0)/255.0, blue: (CGFloat)(decimalC)/255.0, alpha: 1.0)
        
        // shows color based on values chosen
        textColorLabel.textColor =
            UIColor(red: (CGFloat)(decimalA)/255.0, green: (CGFloat)(decimalB)/255.0, blue: (CGFloat)(decimalC)/255.0, alpha: 1.0)
    }
    
    // override function
    //###################################################################################################
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // sets label's default color
        textColorLabel.textColor = UIColor(red: (CGFloat)(r)/255.0, green: (CGFloat)(g)/255.0, blue: (CGFloat)(b)/255.0, alpha: 1.0)
        
        // sets up picker
        colorPicker.dataSource = self;
        colorPicker.delegate = self;
        
    }
}
