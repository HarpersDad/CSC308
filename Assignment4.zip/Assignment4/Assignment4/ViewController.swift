//
//  ViewController.swift
//  Assignment4
//
//  Created by Clifton Lindsey on 2/27/21.
//

import UIKit

class ViewController: UIViewController
{
    // variables
    var imageType = "";
    var selectedImages = "0";
    var frameSpeed = 1.0;
    var isAnim = 0;
    var seconds = "";
    
    // visible image array
    let visibleImages =
    [
        UIImage(named: "visible01.jpg")!,
        UIImage(named: "visible02.jpg")!,
        UIImage(named: "visible03.jpg")!,
        UIImage(named: "visible04.jpg")!,
        UIImage(named: "visible05.jpg")!,
        UIImage(named: "visible06.jpg")!,
        UIImage(named: "visible07.jpg")!,
        UIImage(named: "visible08.jpg")!,
        UIImage(named: "visible09.jpg")!,
        UIImage(named: "visible10.jpg")!,
        UIImage(named: "visible11.jpg")!,
        UIImage(named: "visible12.jpg")!,
        UIImage(named: "visible13.jpg")!,
        UIImage(named: "visible14.jpg")!
    ]
    
    // infrared image array
    let infraredImages =
    [
        UIImage(named: "infrared01.jpg")!,
        UIImage(named: "infrared02.jpg")!,
        UIImage(named: "infrared03.jpg")!,
        UIImage(named: "infrared04.jpg")!,
        UIImage(named: "infrared05.jpg")!,
        UIImage(named: "infrared06.jpg")!,
        UIImage(named: "infrared07.jpg")!,
        UIImage(named: "infrared08.jpg")!,
        UIImage(named: "infrared09.jpg")!,
        UIImage(named: "infrared10.jpg")!,
        UIImage(named: "infrared11.jpg")!,
        UIImage(named: "infrared12.jpg")!,
        UIImage(named: "infrared13.jpg")!,
        UIImage(named: "infrared14.jpg")!
    ]
    
    // ui image variable
    @IBOutlet weak var imageView: UIImageView!
        
    // playback speed text variable
    @IBOutlet weak var playbackSpeedText: UITextView!

    // playback speed stepper input function
    @IBAction func playbackSpeedStepper(_ sender: UIStepper)
    {
        frameSpeed = sender.value;
        
        seconds = String(frameSpeed);
        
        playbackSpeedText.text = "14 Frames in <seconds> Seconds";
        
        playbackSpeedText.text = playbackSpeedText.text.replacingOccurrences(of: "<seconds>", with: seconds);
    }
    
    // sat image type segmented control
    @IBAction func visibleInfraredSelect(_ sender: UISegmentedControl)
    {
        selectedImages = sender.titleForSegment(at: sender.selectedSegmentIndex)!;
        
        // switch case that enables the changing of the UI image when not animated
        switch selectedImages
        {
        case "Visible":
            imageView.image = UIImage(named: "visible01.jpg")!;
            imageType = "visible";
            break;
        case "Infrared":
            imageView.image = UIImage(named: "infrared01.jpg")!;
            imageType = "infrared";
            break;
        default:
            imageView.image = UIImage(named: "visible01.jpg")!;
            imageType = "visible";
            break;
        }
    }
    
    // function that animates the UI images
    func animatedImages(playSpeed :Double)
    {
        if (imageType == "visible")
        {
            imageView.animationImages = visibleImages;
            imageView.animationDuration = playSpeed;
            imageView.image = imageView.animationImages?.first;
            imageView.startAnimating();
            isAnim += 1;
        }
        else
        {
            imageView.animationImages = infraredImages;
            imageView.animationDuration = playSpeed;
            imageView.image = imageView.animationImages?.first;
            imageView.startAnimating();
            isAnim += 1;
        }
    }
    
    // function for playing or stopping the animation
    @IBAction func playStopButton(_ sender: UIButton)
    {
        seconds = String(frameSpeed);
        
        // self explainatory
        playbackSpeedText.text = "14 Frames in <seconds> Seconds";
        playbackSpeedText.text = playbackSpeedText.text.replacingOccurrences(of: "<seconds>", with: seconds);
        
        // calls animation function
        animatedImages(playSpeed: frameSpeed);
        sender.setTitle("Stop", for: UIControl.State.normal)
        
        // used to control the state of the animation
        if (isAnim % 2 == 0)
        {
            imageView.stopAnimating();
            sender.setTitle("Play", for: UIControl.State.normal);
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

