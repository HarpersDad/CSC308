//
//  ViewController.swift
//  Midterm
//
//  Created by Clifton Lindsey on 3/11/21.
//

import UIKit

class ViewController: UIViewController
{
    // initial course grouping
    var courseGroup = "Math-Related";
    
    // variable counter for next button
    var clickCount = 1;
    
    // empty initialized array that will hold currently selected course images
    var courseImages: [UIImage?] = [];

    // math related images array
    var mathRelatedImages =
        [(UIImage(named: "CSC185.png")),
         (UIImage(named: "CSC195.png"))]
    
    // programming related images array
    var programmingReleatedImages =
        [(UIImage(named: "CSC190.png")),
         (UIImage(named: "CSC191.png")),
         (UIImage(named: "CSC308.png"))]
    
    // other related images array
    var otherRelatedImages =
        [(UIImage(named: "CSC310.png")),
         (UIImage(named: "CSC313.png")),
         (UIImage(named: "CSC340.png"))]
    
    // function that puts the correct data on screen depending on user selection
    func dataSelector(image: String, imageArray: [UIImage?], courseTitle: String, starOne: Bool, starTwo: Bool, starThree: Bool, starFour: Bool, starFive: Bool)
    {
        courseDetail.image = UIImage(named: image);
        courseImages = imageArray;
        courseName.text = courseTitle;
        oneStar.isHidden = starOne;
        twoStar.isHidden = starTwo;
        threeStar.isHidden = starThree;
        fourStar.isHidden = starFour;
        fiveStar.isHidden = starFive;
    }

    // segmented control that chooses class type
    @IBAction func courseTypeSelector(_ sender: UISegmentedControl)
    {
        // variable that grabs course type as a String
        courseGroup = sender.titleForSegment(at: sender.selectedSegmentIndex)!;
        
        // switch statement that sets up initial data on screen for each class type
        switch courseGroup
        {
            case "Math-Related":
                
                dataSelector(image: "CSC185.png", imageArray: mathRelatedImages, courseTitle: "CSC 185", starOne: false, starTwo: false, starThree: true, starFour: true, starFive: true)
                clickCount = 1;
                
                break;
                
            case "Programming":
                
                dataSelector(image: "CSC190.png", imageArray: programmingReleatedImages, courseTitle: "CSC 190", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                clickCount = 1;
            
                break;
                
            case "Others":
                
                dataSelector(image: "CSC310.png", imageArray: otherRelatedImages, courseTitle: "CSC 310", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                clickCount = 1;
                
                break;
                
            default:
                break;
        }
        // debug
        //print(courseGroup)
    }
    
    @IBAction func nextCourseInType(_ sender: UIButton)
    {
        // if statement that checks courseGroup selection
        if courseGroup == "Math-Related"
        {
            // switch statement that changes course data depending on how many times the next button is pressed
            switch clickCount
            {
                case 0:
                    
                    dataSelector(image: "CSC185.png", imageArray: mathRelatedImages, courseTitle: "CSC 185", starOne: false, starTwo: false, starThree: true, starFour: true, starFive: true)
                    
                    clickCount = 1;
                    break;
                    
                case 1:
                    
                    dataSelector(image: "CSC195.png", imageArray: mathRelatedImages, courseTitle: "CSC 195", starOne: false, starTwo: false, starThree: false, starFour: false, starFive: true)
                    
                    clickCount = 0
                    break;
                    
                default:
                    break;
            }
        }
        
        // if statement that checks courseGroup selection
        if courseGroup == "Programming"
        {
            // switch statement that changes course data depending on how many times the next button is pressed
            switch clickCount
            {
                case 0:
                    
                    dataSelector(image: "CSC190.png", imageArray: programmingReleatedImages, courseTitle: "CSC 190", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                    
                    clickCount = 1;
                    break;
                    
                case 1:
                    dataSelector(image: "CSC191.png", imageArray: programmingReleatedImages, courseTitle: "CSC 191", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                    clickCount = 2
                    break;
                    
                case 2:
                    dataSelector(image: "CSC308.png", imageArray: programmingReleatedImages, courseTitle: "CSC 308", starOne: false, starTwo: false, starThree: true, starFour: true, starFive: true)
                    clickCount = 0
                    break;
                    
                default:
                    break;
            }
        }
        
        // if statement that checks courseGroup selection
        if courseGroup == "Others"
        {
            // switch statement that changes course data depending on how many times the next button is pressed
            switch clickCount
            {
                case 0:
                    dataSelector(image: "CSC310.png", imageArray: otherRelatedImages, courseTitle: "CSC 310", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                    clickCount = 1;
                    break;
                    
                case 1:
                    dataSelector(image: "CSC313.png", imageArray: otherRelatedImages, courseTitle: "CSC 313", starOne: false, starTwo: false, starThree: true, starFour: true, starFive: true)
                    clickCount = 2
                    break;
                    
                case 2:
                    dataSelector(image: "CSC340.png", imageArray: otherRelatedImages, courseTitle: "CSC 340", starOne: false, starTwo: false, starThree: false, starFour: true, starFive: true)
                    clickCount = 0
                    break;
                    
                default:
                    break;
            }
        }
    }
    
    // courseDetail is the image with pertinent course data
    @IBOutlet weak var courseDetail: UIImageView!
    
    // courseName shows the course name
    @IBOutlet weak var courseName: UILabel!
    
    // *star shows current difficulty level for the course
    @IBOutlet weak var oneStar: UIImageView!
    
    // *star shows current difficulty level for the course
    @IBOutlet weak var twoStar: UIImageView!
    
    // *star shows current difficulty level for the course
    @IBOutlet weak var threeStar: UIImageView!
    
    // *star shows current difficulty level for the course
    @IBOutlet weak var fourStar: UIImageView!
    
    // *star shows current difficulty level for the course
    @IBOutlet weak var fiveStar: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

