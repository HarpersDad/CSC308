//
//  ViewController.swift
//  assignment6
//
//  Created by Clifton Lindsey on 3/22/21.
//

import UIKit

protocol catChange
{
    func newCat(a: Int);
}

class ViewController: UIViewController, catChange
{
    // initializer for randNum variable
    var randNumA = 0;
    var randNumB = 0;
    var randNumC = 0;
    
    // variables to check if the correct image is chosen
    var choiceA = 0;
    var choiceB = 0;
    
    // empty array
    var tempArray: [Int] = [];
    
    // sender placeholders
    var imageA = UIButton();
    var imageB = UIButton();
    
    // dictionary containing the different images used in app
    var imageDict =
        [
            // flowers
            1 : UIImage(named: "flowerA.jpeg"),
            2 : UIImage(named: "flowerB.jpeg"),
            3 : UIImage(named: "flowerC.jpeg"),
            4 : UIImage(named: "flowerD.jpeg"),
            5 : UIImage(named: "flowerE.jpeg"),
            
            // food
            6 : UIImage(named: "foodA.jpeg"),
            7 : UIImage(named: "foodB.jpeg"),
            8 : UIImage(named: "foodC.jpeg"),
            9 : UIImage(named: "foodD.jpeg"),
            
            // vehicles
            10 : UIImage(named: "vehicleA.jpeg"),
            11 : UIImage(named: "vehicleB.jpeg"),
            12 : UIImage(named: "vehicleC.jpeg"),
            13 : UIImage(named: "vehicleD.jpeg"),
            14 : UIImage(named: "vehicleE.jpeg"),
            15 : UIImage(named: "vehicleF.jpeg"),
        ]
    
    // number array used to set UIImages behind the UIButtons
    var numArray =
        [
            // flowers
            1,
            2,
            3,
            4,
            
            // food
            5,
            6,
            7,
            8,
            9,
            
            // vehicles
            10,
            11,
            12,
            13,
            14,
            15
        ]
    
    // category image
    @IBOutlet weak var category_Image: UIImageView!
    
    
    // button that allows you to change the image category
    @IBAction func change_Category(_ sender: UIButton)
    {
        // nothing is in here!!!!
    }
    
    // variable for image option A
    @IBOutlet weak var image_A: UIImageView!
    
    // function for the image option a button
    @IBAction func image_Option_A(_ sender: UIButton)
    {
        imageA = sender;
        
        if (choiceA == randNumC)
        {
            // debug
            //print("Correct");
            
            // creates pop-up window
            let alertController = UIAlertController(title: "Thank You", message: ("Congratulations.  You are correct."), preferredStyle: UIAlertController.Style.alert);
            
            present(alertController, animated: true, completion: nil);
            
            let resetApp = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default)
            {
                [self]_ in
                
                    viewDidLoad();
            }
            
            alertController.addAction(resetApp)
        }
        else
        {
            // creates pop-up window
            let alertController = UIAlertController(title: "Thank You", message: ("Sorry.  You are wrong."), preferredStyle: UIAlertController.Style.alert);
            
            present(alertController, animated: true, completion: nil);
            
            let resetApp = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default)
            {
                [self]_ in
                
                    viewDidLoad();
            }
            
            alertController.addAction(resetApp)
        }
        
        // debug
        //print("A has been clicked")
    }
    
    // variable for image option B
    @IBOutlet weak var image_B: UIImageView!
    
    // function for the image option b button
    @IBAction func image_Option_B(_ sender: UIButton)
    {
        imageB = sender;
        
        if (choiceB == randNumC)
        {
            // debug
            //print("Correct");
            
            // creates pop-up window
            let alertController = UIAlertController(title: "Thank You", message: ("Congratulations.  You are correct."), preferredStyle: UIAlertController.Style.alert);
            
            // shows pop-up
            present(alertController, animated: true, completion: nil);
            
            // adds "Ok" button to pop-up
            let resetApp = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default)
            {
                [self]_ in
                
                    // calls function when pressed
                    viewDidLoad();
            }
            
            // gives "Ok" button an action when pressed
            alertController.addAction(resetApp)
        }
        else
        {
            // creates pop-up window
            let alertController = UIAlertController(title: "Thank You", message: ("Sorry.  You are wrong."), preferredStyle: UIAlertController.Style.alert);
            
            // shows pop-up
            present(alertController, animated: true, completion: nil);
            
            // adds "Ok" button to pop-up
            let resetApp = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default)
            {
                [self]_ in
                
                    // calls function when pressed
                    viewDidLoad();
            }
            
            //gives "Ok" button an action when pressed
            alertController.addAction(resetApp)
        }
        
        // debug
        //print("B has been clicked")
    }
    
    // function that allows you to get new image choices
    @IBAction func new_Image_Options(_ sender: UIButton)
    {
        // calls function
        randNums();
    }
    
    // function that changes category image after user selects new category
    func newCat(a: Int)
    {
        switch a
        {
            case 1:
                
                // assigns rNC a random number from the array
                randNumC = Int.random(in: 1..<6);
                
                // uses the number rNC to set up the image for the chosen category
                category_Image.image = imageDict[randNumC]!;
                
                // calls randNums function to set user input images
                randNums();
                
                break;
                
            case 2:
                
                // assigns rNC a random number from the array
                randNumC = Int.random(in: 6..<10);
                
                // uses the number rNC to set up the image for the chosen category
                category_Image.image = imageDict[randNumC]!;
                
                // calls randNums function to set user input images
                randNums();
                
                break;
                
            case 3:
                
                // assigns rNC a random number from the array
                randNumC = Int.random(in: 10..<16);
                
                // uses the number rNC to set up the image for the chosen category
                category_Image.image = imageDict[randNumC]!;
                
                // calls randNums function to set user input images
                randNums();
                
                break;
            
            default:
                break;
        }
    }
    
    // function that sets the random numbers used to randomly select what images are used
    func randNums()
    {
        // random number used to set position of image buttons
        let posNum = Int.random(in: 1...100);
        
        // sets up a temp array as numArray
        tempArray = numArray;
        
        // the following if statements are broken up according to rNC's position in tempArray
        
        // randNumC < 6
        if (randNumC < 6)
        {
            //debug
            //print("C: ", randNumC);
            
            // sets rNA as a random number between 0 and 6
            randNumA = Int.random(in: 1..<6);
            
            // loops until rNA is a number that falls within the specified group, but is not equal to rNC
            while(randNumA == randNumC)
            {
                randNumA = Int.random(in: 1..<6);
            }
            
            // debug
            //print("A: ", randNumA);
            
            // sets rNB as a random number between 0 and 6
            randNumB = Int.random(in: 6..<16);
            
            // loops until rNB is a number that falls within the specified group, but is not equal to rnA or rNC
            while(randNumB == randNumA || randNumB == randNumC)
            {
                randNumB = Int.random(in: 6..<16);
            }
        }
        
        // randNumC < 10 and > 5
        if (randNumC < 10 && randNumC > 5)
        {
            // debug
            //print("C: ", randNumC);
            
            //sets rNA as a random number between 5 and 10
            randNumA = Int.random(in: 6..<10);
            
            // loops until rNA is a number that falls within the specified group, but is not equal to rNC
            while(randNumA == randNumC)
            {
                randNumA = Int.random(in: 6..<10);
            }
            
            //debug
            //print("A: ", randNumA);
            
            // creates an array that allows us to set rNB as any number outside of the specified group
            let specialArray = [1,2,3,4,5,10,11,12,13,14,15];
            
            // sets rNB as a random number outside of the specified group
            randNumB = specialArray.randomElement()!;
        }
        
        // randNumC < 16 and > 9
        if (randNumC < 16 && randNumC > 9)
        {
            // debug
            //print("C: ", randNumC);
            
            // sets rNA as a random number between 0 and 11
            randNumA = Int.random(in: 10..<16);
            
            // loops until rNA is a number that falls within the specified group, but is not equal to rNC
            while(randNumA == randNumC)
            {
                randNumA = Int.random(in: 10..<16);
            }
            
            // sets rNB as a random number between 0 and 11
            randNumB = Int.random(in: 1..<10);
            
            // loops until rNB is a number that falls within the specified group, but is not equal to rnA or rNC
            while(randNumB == randNumA || randNumB == randNumC)
            {
                randNumB = Int.random(in: 1..<10);
            }
        }
        
        // if else statement that sets up the images for user choice based on if posNum can be equally divided by 2
        if ((posNum % 2) != 0)
        {
            // sets selection images
            image_A.image = imageDict[randNumA]!;
            image_B.image = imageDict[randNumB]!;
            
            
            // sets variable to check if correct option is chosen
            choiceA = randNumC;
            
        }
        else
        {
            // sets selection images
            image_A.image = imageDict[randNumB]!;
            image_B.image = imageDict[randNumA]!;
            
            // sets variable to check if correct variable is chosen
            choiceB = randNumC;
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // assigns rNC a random number from the array
        randNumC = numArray.randomElement()!;
        
        // uses the number rNC to set up the image for the chosen category
        category_Image.image = imageDict[randNumC]!;
        
        // debug
        //print("C: ", randNumC);
        
        // calls randNums function
        randNums();
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
            if let destination = segue.destination as? CategorySelectViewController
            {
                destination.delegate = self;
                // Other initializations as needed
            }
        }
}

